# bot-wa by Ahmad

# Cara install bot:
#
#>pkg update && pkg upgrade

#>pkg install git

#>git clone https://github.com/Ahmad-script/bot-wa

#>cd bot-wa

#>pkg install wget

#>pkg install ffmpeg

#>pkg install nodejs

#>npm i -g cwebp

#>npm i -g ytdl

#>npm i

#>npm i got

#>node index.js

